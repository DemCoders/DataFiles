﻿$importfolder= "D:\dev\scenario4\EMLs\E2M\"
$pathToScript= "D:\dev\scenario4\Scripts\"
$saveInFolder= "OT"



$importFromFolder = get-childitem $importfolder
                                         
                                        
                  $importFromFolder| % {
                                         
                        $ToStep1 = get-content ($_.fullname.ToString()) | select-string "X-Receiver: "
                        $importEmail = $_.FullName
                         
                         $ToStep1 | % {
                            $a= $_.tostring() 
                            $to= $a.Replace("X-Receiver: ","")
                            $to = $to.trim()
                        
                            $commandOutput=  $pathToScript + "EMLtoMailbox_cloudv2.ps1 -mailbox " + $to +  " -importEmail "  + $importEmail +  " -saveinfolder " + $saveInFolder
                            Write-host $commandOutput
                                            invoke-command { 
                                                   try{ 
                                                    start PowerShell "$commandOutput" -WindowStyle Hidden
                                                    sleep 1}
                                                    Catch{error}
                                                      }
                                     }


                                     }