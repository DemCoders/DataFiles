﻿Param(
	[Parameter(Mandatory = $true)]
	[string] $mailbox = "",
	[Parameter(Mandatory = $true)]
	[string] $importEmail = "",
	[Parameter(Mandatory = $true)]
	[string] $SaveinFolder = ""
)

Function GetRandomDateBetween{
        <#
        .EXAMPLE
        Get-RandomDateBetween -StartDate (Get-Date) -EndDate (Get-Date).AddDays(-15)
        #>
        [Cmdletbinding()]
        param(
            [parameter(Mandatory=$True)][DateTime]$StartDate,
            [parameter(Mandatory=$True)][DateTime]$EndDate
            )

        process{
           return Get-Random -Minimum $StartDate.Ticks -Maximum $EndDate.Ticks | Get-Date -Format "ddd, dd MMM yyyy HH':'mm':'ss 'GMT'"
        }
    }

    ## Ignore Certificate Prompts
add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

$dllpath = "C:\dev\Microsoft.Exchange.WebServices.dll"
Import-Module $dllpath

## Set Exchange Version
$ExchangeVersion = [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2013_SP1
$service = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService($ExchangeVersion)
#$uri=[system.URI] "https://outlook.office365.com/ews/exchange.asmx"
$uri=[system.URI] "https://ews3.a360labs.com/ews/exchange.asmx"
$service.url = $uri
#$service.AutodiscoverUrl($mailbox,{$true})

                                            $userName="a360-mbximper@a360labs.com"
                                            $password= "Letmein001--"
                                            $service.Credentials = New-Object Microsoft.Exchange.WebServices.Data.WebCredentials -ArgumentList $userName, $password
        


$service.ImpersonatedUserId = New-Object Microsoft.Exchange.WebServices.Data.ImpersonatedUserId `
([Microsoft.Exchange.WebServices.Data.ConnectingIdType]::SMTPAddress,$Mailbox);




#Get folder to import
 $MailboxRootid= new-object Microsoft.Exchange.WebServices.Data.FolderId `
    ([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::MsgFolderRoot,$Mailbox)
    $MailboxRoot=[Microsoft.Exchange.WebServices.Data.Folder]::Bind($service,$MailboxRootid)
    $FolderList = new-object Microsoft.Exchange.WebServices.Data.FolderView(100)
    $FolderList.Traversal = [Microsoft.Exchange.WebServices.Data.FolderTraversal]::Deep
    $findFolderResults = $MailboxRoot.FindFolders($FolderList)
    $allFolders=$findFolderResults | ? {$_.FolderClass -eq "IPF.Note" } | select ID,Displayname
    $DI = $allFolders | ? {$_.DisplayName -eq $SaveinFolder} 
    $Folderid=$DI.ID

    if([string]::IsNullOrEmpty($Folderid.ChangeKey) -eq $true){

        $allFolders=$findFolderResults | ? {$_.FolderClass -eq "IPF.Note" } | select ID,Displayname
        $parentFolderID = $allFolders | ? {$_.DisplayName -eq "inbox"} 
        $newFolder = new-object Microsoft.Exchange.WebServices.Data.Folder($service)
        $newFolder.DisplayName = $SaveinFolder
        $newFolder.FolderClass = "IPF.Note"
        $newfolder.Save($parentFolderID.Id)
        $findFolderResults = $MailboxRoot.FindFolders($FolderList)
        $allFolders=$findFolderResults | ? {$_.FolderClass -eq "IPF.Note" } | select ID,Displayname
        $DI = $allFolders | ? {$_.DisplayName -eq $SaveinFolder} 
        $Folderid=$DI.ID

        }

    
#Crete Email Object
#$emailsinfolder=Get-ChildItem $ImportFromFolder | ? {$_.name -like "*.Eml" }
#$emailsinfolder=Get-ChildItem $ImportFromFolder | ? {$_.name -like "*.Eml" }


            $EmailtoImport= $importFromFolder
            Write-host "Importing Email:" $importEmail
           
             $date = (GetRandomDateBetween -StartDate (Get-Date).AddDays(-2014) -EndDate (Get-Date).AddDays(-419))

            $UploadEmail = new-object Microsoft.Exchange.WebServices.Data.EmailMessage($service)
            $extSubmit = New-Object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(0057,[Microsoft.Exchange.WebServices.Data.MapiPropertyType]::SystemTime) 
            $extDelivery = New-Object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(3590,[Microsoft.Exchange.WebServices.Data.MapiPropertyType]::SystemTime) 
            $PR_Flags = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(3591, [Microsoft.Exchange.WebServices.Data.MapiPropertyType]::Integer);  
             
                        
            $uploadEmail.SetExtendedProperty($extSubmit,$date)
            $uploadEmail.SetExtendedProperty($extDelivery, $date)
            $UploadEmail.SetExtendedProperty($PR_Flags,"1") 
                       
            #Read File  
            [byte[]]$EmailinByte=get-content -encoding byte $importEmail
            #Set Mime Content in Message  
            
            $UploadEmail.MimeContent = new-object Microsoft.Exchange.WebServices.Data.MimeContent("us-ascii", $Emailinbyte);
                        
            $UploadEmail.Save($Folderid)
            
            #$UploadEmail.SendAndSaveCopy($Folderid)
            #$UploadEmail = $null
                        
            
                                   

                                   