﻿$importfolder= "C:\dev\scenarios\Scenario3\EMLs\iw2m\"
$pathToScript= "C:\dev\scenarios\Scenario3\scripts\"
$saveInFolder= "personal"



$importFromFolder = get-childitem $importfolder
                                         
                                        
                  $importFromFolder| % {
                                         
                        $ToStep1 = get-content ($_.fullname.ToString()) | select-string "X-Receiver: "
                        $importEmail = $_.FullName
                         
                         $ToStep1 | % {
                            $a= $_.tostring() 
                            $to= $a.Replace("X-Receiver: ","")
                            $to = $to.trim()
                        
                            $commandOutput=  $pathToScript + "EMLtoMailbox_onpremv2.ps1 -mailbox " + $to +  " -importEmail "  + $importEmail +  " -saveinfolder " + $saveInFolder
                            Write-host $commandOutput
                                            invoke-command { 
                                                   try{ 
                                                    start PowerShell "$commandOutput" -WindowStyle Hidden
                                                    sleep 2}
                                                    Catch{error}
                                                      }
                                     }


                                     }